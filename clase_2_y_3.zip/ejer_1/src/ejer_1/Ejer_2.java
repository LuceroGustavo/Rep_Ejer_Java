/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejer_1;


import java.util.Scanner;

/**
2. Escribir un programa que pida tu nombre, lo guarde en una variable y lo
muestre por pantalla.
 */
public class Ejer_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        
        System.out.println("Ingese un nombre");
       
    String nombre = leer.nextLine();
        
    
     System.out.println("El nombre ingresado es " + nombre);
        
    }

     
        }
    
    

