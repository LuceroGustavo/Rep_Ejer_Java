/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejer_1;


import java.util.Scanner;

/**
Escribir un programa que pida una frase y la muestre toda en mayúsculas
y después toda en minúsculas.
Nota: investigar la función toUpperCase() y toLowerCase() en Java.
 */
public class Ejer_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        
        System.out.println("Ingese una frase");
       
    String palabra = leer.nextLine();
        
    
     System.out.println("La Frase en minuscula es " + palabra.toLowerCase());
     System.out.println("La Frase en MAYUSCULA es " + palabra.toUpperCase());
        
    }

     
        }
    
    

