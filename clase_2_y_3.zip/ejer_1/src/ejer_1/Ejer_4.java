/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejer_1;


import java.util.Scanner;

/**
Dada una cantidad de grados centígrados se debe mostrar su
equivalente en grados Fahrenheit. La fórmula correspondiente es: F = 32
+ (9 * C / 5).
 */
public class Ejer_4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        
        System.out.println("Ingrese Grados Centigrados");
       
    double grados = leer.nextDouble();
    //double f = 32 + (9*grados/5) ;
        
    
     System.out.println("corresponde a  " + 32 + (9*grados/5)+ "°");
    
        
    }

     
        }
    
    

